$forceload remove $(x) $(z)
